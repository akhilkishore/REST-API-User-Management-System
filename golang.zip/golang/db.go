package main

import (
	"database/sql"
	_"github.com/go-sql-driver/mysql"
	"fmt"
)
type Tag struct {
    Name string `json:"name"`
}
//t := time.Now()
//t := t.Format("2006-01-02 15:04:05")


func main(){
	db, err := sql.Open("mysql", "dummyUser:dummyUser01@tcp(db-intern.ciupl0p5utwk.us-east-1.rds.amazonaws.com:3306)/db_intern")
	if err != nil {
	fmt.Println(err)
	}else{
	fmt.Println("Connection Established")
	}
	defer db.Close()

    // perform a db.Query insert
    insert, err := db.Query("select userName from userData")

    // if there is an error inserting, handle it
    if err != nil {
        panic(err.Error())
	}
	for insert.Next() {
        var tag Tag
        // for each row, scan the result into our tag composite object
        err = insert.Scan(&tag.Name)
        if err != nil {
            panic(err.Error()) // proper error handling instead of panic in your app
        }
                // and then print out the tag's Name attribute
		fmt.Println(tag.Name)
    }

    // be careful deferring Queries if you are using transactions
	defer insert.Close()
}