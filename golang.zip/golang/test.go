package main

import (
	"time"
	"fmt"
	"log"
	"net/http"
	"database/sql"
	_"github.com/go-sql-driver/mysql"
) 

type Tag struct {
    Name string `json:"name"`
}

func hello( w http.ResponseWriter, r *http.Request){
	if r.URL.Path != "/"{
		http.Error(w, "404 not found.", http.StatusNotFound )
		return
	}
	switch  r.Method {
	case "GET":
		http.ServeFile(w, r, "index.html")
	default:
		fmt.Fprintf(w,"sorry2")
	}
}

func inse(w http.ResponseWriter, r *http.Request){
	db, err := sql.Open("mysql", "dummyUser:dummyUser01@tcp(db-intern.ciupl0p5utwk.us-east-1.rds.amazonaws.com:3306)/db_intern")
	if err != nil {
	fmt.Println(err)
	}else{
	fmt.Println("Connection Established")
	}
	defer db.Close()
	switch  r.Method {
	case "GET":
		email := r.FormValue("email1")
		fmt.Println(email)
		fmt.Println("workng")
		insert, err := db.Query("select userName from userData where emailId = ?",email)
    	// if there is an error inserting, handle it
    	if err != nil {
        	panic(err.Error())
		}
		for insert.Next() {
        	var tag Tag
        	err = insert.Scan(&tag.Name)
        	if err != nil {
            	panic(err.Error())
        	}
			fmt.Println(tag.Name)
   		}
		http.ServeFile(w, r, "second.html")
		fmt.Fprintf(w, "ParseForm() err: %v", err)
	case "POST":
		if err := r.ParseForm(); err != nil{
			fmt.Fprintf(w, "ParseForm() err: %v", err)
			return
		}
		name := r.FormValue("name")
		email := r.FormValue("email")
		pwd := r.FormValue("pwd")
		phone := r.FormValue("phone")
		t := time.Now()
		t1 := t.String()
		http.ServeFile(w, r, "second.html")
		insert, err:= db.Prepare("INSERT INTO userData(userName, emailId, phoneNo, password, dateTime) VALUES(?,?,?,?,?)")
		insert.Exec(name, email, pwd, phone, t1)
		fmt.Fprintf(w, "ParseForm() err: %v", err)
	default:
		fmt.Fprintf(w,"sorry2")
	}
}
func dele(w http.ResponseWriter, r *http.Request){

	switch  r.Method {
	case "POST":
		if err := r.ParseForm(); err != nil{
			fmt.Fprintf(w, "ParseForm() err: %v", err)
			return
		}
		email := r.FormValue("email1")
		http.ServeFile(w, r, "deleted.html") //call different page
		insert, err := db.Query("delete from userData where emailId = ?",email)
		fmt.Fprintf(w, "ParseForm() err: %v", err)
	default:
		fmt.Fprintf(w,"sorry2")
	}
}

func main(){
	http.HandleFunc("/",hello)
	http.HandleFunc("/insert",inse)
	http.HandleFunc("/delete",dele)
	fmt.Printf("Starting server")
	if err := http.ListenAndServe(":8080",nil); 
	err != nil{
		log.Fatal(err)
	}
}
